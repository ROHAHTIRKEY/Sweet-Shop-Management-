from django.apps import AppConfig


class ShoppingBagConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shopping_bag'
